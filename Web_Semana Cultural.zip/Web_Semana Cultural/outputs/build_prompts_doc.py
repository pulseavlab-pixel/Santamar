﻿from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.enum.section import WD_SECTION
from docx.enum.style import WD_STYLE_TYPE
import os

OUT = r"C:\Users\dportugues\OneDrive - GAM\Documentos\Web_Semana Cultural\outputs\Guia_Prompts_Magnific_Santamar_2026.docx"
os.makedirs(os.path.dirname(OUT), exist_ok=True)

doc = Document()
sec = doc.sections[0]
sec.top_margin = Inches(0.75)
sec.bottom_margin = Inches(0.75)
sec.left_margin = Inches(0.75)
sec.right_margin = Inches(0.75)

styles = doc.styles
normal = styles['Normal']
normal.font.name = 'Calibri'
normal._element.rPr.rFonts.set(qn('w:eastAsia'), 'Calibri')
normal.font.size = Pt(10.5)
normal.paragraph_format.space_after = Pt(5)
normal.paragraph_format.line_spacing = 1.15

for name, size, color in [('Heading 1', 16, '12355B'), ('Heading 2', 13, '0E7C7B'), ('Heading 3', 11.5, '1F4D78')]:
    st = styles[name]
    st.font.name = 'Calibri'
    st._element.rPr.rFonts.set(qn('w:eastAsia'), 'Calibri')
    st.font.size = Pt(size)
    st.font.bold = True
    st.font.color.rgb = RGBColor.from_string(color)
    st.paragraph_format.space_before = Pt(10)
    st.paragraph_format.space_after = Pt(4)

if 'PromptBox' not in styles:
    st = styles.add_style('PromptBox', WD_STYLE_TYPE.PARAGRAPH)
    st.font.name = 'Consolas'
    st._element.rPr.rFonts.set(qn('w:eastAsia'), 'Consolas')
    st.font.size = Pt(9)
    st.paragraph_format.space_before = Pt(3)
    st.paragraph_format.space_after = Pt(6)
    st.paragraph_format.left_indent = Inches(0.15)

if 'SmallNote' not in styles:
    st = styles.add_style('SmallNote', WD_STYLE_TYPE.PARAGRAPH)
    st.font.name = 'Calibri'
    st.font.size = Pt(9)
    st.font.color.rgb = RGBColor(85,85,85)
    st.paragraph_format.space_after = Pt(4)


def shade_cell(cell, fill):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement('w:shd')
    shd.set(qn('w:fill'), fill)
    tcPr.append(shd)

def set_cell_text(cell, text, bold=False, color=None):
    cell.text = ''
    p = cell.paragraphs[0]
    p.paragraph_format.space_after = Pt(0)
    r = p.add_run(text)
    r.bold = bold
    if color:
        r.font.color.rgb = RGBColor.from_string(color)
    r.font.size = Pt(9)

def set_table_widths(table, widths):
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    for row in table.rows:
        for idx, width in enumerate(widths):
            row.cells[idx].width = Inches(width)
            row.cells[idx].vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.TOP

def h1(text): doc.add_heading(text, level=1)
def h2(text): doc.add_heading(text, level=2)
def h3(text): doc.add_heading(text, level=3)
def p(text, style=None):
    para = doc.add_paragraph(style=style)
    para.add_run(text)
    return para

def bullet(text):
    para = doc.add_paragraph(style='List Bullet')
    para.paragraph_format.space_after = Pt(2)
    para.add_run(text)
    return para

def num(text):
    para = doc.add_paragraph(style='List Number')
    para.paragraph_format.space_after = Pt(2)
    para.add_run(text)
    return para

def prompt_box(label, text):
    t = doc.add_table(rows=1, cols=1)
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    cell = t.cell(0,0)
    shade_cell(cell, 'F7FAFC')
    p0 = cell.paragraphs[0]
    p0.paragraph_format.space_after = Pt(3)
    r = p0.add_run(label)
    r.bold = True
    r.font.color.rgb = RGBColor.from_string('12355B')
    r.font.size = Pt(9)
    para = cell.add_paragraph(style='PromptBox')
    para.add_run(text)
    for c in t._tbl.iter_tcs():
        tcPr = c.get_or_add_tcPr()
        tcMar = OxmlElement('w:tcMar')
        for m in ['top','left','bottom','right']:
            node = OxmlElement(f'w:{m}')
            node.set(qn('w:w'), '120')
            node.set(qn('w:type'), 'dxa')
            tcMar.append(node)
        tcPr.append(tcMar)
    doc.add_paragraph().paragraph_format.space_after = Pt(1)

# Cover
cover = doc.add_paragraph()
cover.alignment = WD_ALIGN_PARAGRAPH.CENTER
r = cover.add_run('Guía de prompts y rodaje\nSantamar 2026')
r.bold = True; r.font.size = Pt(24); r.font.color.rgb = RGBColor.from_string('12355B')
sub = doc.add_paragraph()
sub.alignment = WD_ALIGN_PARAGRAPH.CENTER
rr = sub.add_run('La Noche del Eclipse - V Fiesta Ibicenca - Semana Cultural')
rr.font.size = Pt(13); rr.font.color.rgb = RGBColor.from_string('0E7C7B')
p('Documento operativo para crear vídeos e imágenes con dron, fotos reales y Magnific. Preparado para trabajar pieza por pieza con material propio de Santa María del Río.', 'SmallNote')

h1('1. Cómo usar este documento')
for item in [
    'Primero grabad las tomas de la sección 3. Sin ese banco visual, los prompts no tendrán material suficiente.',
    'Para cada pieza, subid a Magnific los clips/fotos indicados y pegad el prompt exacto de la ficha.',
    'Exportad siempre en vertical 9:16 para Reels y Stories. Para carruseles, cread también versiones 4:5.',
    'No intentéis que la IA invente Santamar. Usad siempre fotos y vídeos reales del pueblo, gente, carteles, DJs o ediciones anteriores.',
    'Mantened una identidad: blanco, dorado, azul noche, eclipse, textura rural premium y comunidad real.'
]: bullet(item)

h1('2. Ajustes generales para todos los vídeos')
settings = [
    ['Formato principal', 'Reel vertical 9:16, 1080 x 1920 px, 24 o 30 fps.'],
    ['Duración ideal', 'Teaser: 7-12 s. Reveal/informativo: 12-20 s. Aftermovie: 20-35 s.'],
    ['Hook', 'Primer texto antes del segundo 1.5. Nada de intros largas.'],
    ['Música', 'Base electrónica/house suave para teasers; subida clara para reveals; música más emocional para pueblo/comunidad.'],
    ['Color', 'Blanco limpio, dorado solar, azul noche, contraste medio. Evitar saturación de postal turística falsa.'],
    ['Tipografía', 'Titulares grandes, máximo 5-7 palabras por pantalla. Usar la misma familia visual en todos los vídeos.'],
    ['Logo', 'Pequeño, al final o esquina inferior. No tapar caras ni el campanario/plaza.'],
    ['CTA', 'Seguir, guardar, compartir, etiquetar al grupo, activar recordatorio o visitar santamar.org.']
]
table = doc.add_table(rows=1, cols=2)
set_cell_text(table.cell(0,0),'Parámetro', True, 'FFFFFF'); set_cell_text(table.cell(0,1),'Decisión', True, 'FFFFFF')
shade_cell(table.cell(0,0),'12355B'); shade_cell(table.cell(0,1),'12355B')
for a,b in settings:
    row = table.add_row().cells
    set_cell_text(row[0], a, True, '12355B')
    set_cell_text(row[1], b)
set_table_widths(table, [1.6, 5.4])

h1('3. Banco de imágenes y vídeos que hay que tomar')
h2('3.1 Tomas de dron imprescindibles')
shots = [
    ['D01', 'Entrada al pueblo desde carretera', 'Amanecer o golden hour', 'Teaser Santamar despierta, última semana, guía práctica', 'Vuelo lento hacia delante, altura media, sin giros bruscos.'],
    ['D02', 'Plano cenital del pueblo', 'Mediodía claro', 'Teaser eclipse, cuenta atrás, programa', 'Subida vertical o dron quieto con leve avance.'],
    ['D03', 'Plaza / centro del pueblo', 'Atardecer', 'Noche del Eclipse, FOMO blanco, aftermovie', 'Movimiento orbital lento si es seguro.'],
    ['D04', 'Iglesia/campanario o elemento reconocible', 'Golden hour', 'Identidad, orgullo de pueblo', 'Mantener horizonte estable; dejar espacio para texto superior.'],
    ['D05', 'Río/campos/alrededores', 'Atardecer', 'Pueblo, calma antes de fiesta', 'Planos largos de 8-12 s para transiciones.'],
    ['D06', 'Calles vacías antes del evento', 'Mañana temprano', 'Antes del gran día, cuenta atrás', 'Sensación de espera. Evitar coches modernos protagonistas.'],
    ['D07', 'Montaje de escenario/barra/decoración', '7-12 agosto', 'El pueblo se prepara, última semana', 'Dron bajo solo si es seguro; alternar con tomas a mano.'],
    ['D08', 'Plano general con gente vestida de blanco', '12 agosto tarde', 'Día grande, aftermovie', 'Grabar 5-8 clips cortos desde distancia segura.'],
    ['D09', 'Atardecer del 12 agosto', '12 agosto', 'Mañana eclipse, teaser aftermovie', 'Exponer bien el cielo; no mirar/grabar el sol sin seguridad.'],
    ['D10', 'Plano final nocturno o luces', '12 agosto noche', 'Aftermovie corto', 'Si el dron no es seguro de noche, sustituir por móvil/gimbal.']
]
t = doc.add_table(rows=1, cols=5)
for i,h in enumerate(['ID','Toma','Momento','Uso','Indicaciones']): set_cell_text(t.cell(0,i), h, True, 'FFFFFF'); shade_cell(t.cell(0,i),'12355B')
for rowdata in shots:
    row=t.add_row().cells
    for i,val in enumerate(rowdata): set_cell_text(row[i], val, i==0, '12355B' if i==0 else None)
set_table_widths(t,[0.45,1.55,1.05,1.65,2.3])

h2('3.2 Tomas a pie y fotos necesarias')
for item in [
    'Cartel vertical y horizontal en buena luz, sin reflejos, con fondo limpio.',
    'Gente del pueblo preparando cosas: manos colocando luces, pancartas, mesas, sillas, barra, camisetas.',
    'Detalles blancos: ropa blanca, vasos, luces, pulseras, tela, decoración, camiseta Santamar.',
    'Retratos naturales de vecinos y jóvenes mirando a cámara, sonriendo o caminando por el pueblo.',
    'Fotos de patrocinadores/comercios si van a etiquetarse: fachada, producto o equipo.',
    'Planos recurso: campanas, calle, sombras, pies caminando, manos brindando, niños jugando, cartel en pared.',
    'Vídeos verticales de ediciones anteriores: baile, entrada, barra, DJs, público, luces y cierre.',
    'Clips de los DJs o material oficial de artista, siempre con permiso para publicar.',
    'Capturas limpias de santamar.org en móvil para el Reel/carrusel de landing.',
    'Fotos del programa impreso cuando esté cerrado, pero también diseño digital en alta calidad.'
]: bullet(item)

h2('3.3 Qué evitar al grabar')
for item in [
    'Vídeos horizontales sin versión vertical si el destino es Instagram Reels.',
    'Planos con demasiada gente de espaldas y sin emoción visible.',
    'Carteles con texto pequeño usados como vídeo principal.',
    'Dron con movimientos rápidos, inclinados o mareantes.',
    'IA que cambie la arquitectura real del pueblo o convierta Santamar en un sitio genérico.',
    'Textos encima de caras, del cielo importante o del elemento reconocible del pueblo.'
]: bullet(item)

h1('4. Prompts maestros para Magnific')
p('Estos prompts se pueden reutilizar como base. Después, cada ficha de vídeo incluye un prompt específico.', 'SmallNote')
prompt_box('Prompt maestro A - Dron cinematográfico del pueblo', 'Mejora este vídeo real de dron de Santa María del Río manteniendo fielmente la arquitectura, calles, colores y proporciones reales. Crear un acabado cinematográfico premium para campaña de Instagram: luz dorada de verano, contraste medio, blancos limpios, azul de cielo natural, detalle nítido en tejados y campos, sensación de pueblo vivo y elegante. No inventes edificios, no añadas personas, no cambies la geografía, no deformes campanarios ni tejados. Preparar para Reel vertical 9:16 con espacio limpio en la parte superior para texto grande.')
prompt_box('Prompt maestro B - Estética eclipse / noche ibicenca', 'Transforma el material real en una pieza visual de evento premium: ambiente de eclipse de verano, energía ibicenca, dress code blanco, tonos azul noche, dorado solar y blanco luminoso. Mantener todo realista y reconocible. Intensificar la atmósfera sin hacerlo fantástico ni artificial. No añadir multitudes falsas, no añadir escenarios inexistentes, no cambiar rostros. El resultado debe parecer un vídeo promocional real de Santamar White Festival.')
prompt_box('Prompt maestro C - Foto/carrusel de cartel premium', 'Mejorar esta imagen o composición para que parezca parte de una campaña cultural premium: alta nitidez, contraste equilibrado, blancos limpios, negros suaves, dorado solar y azul noche. Mantener texto legible, no alterar nombres, fechas, logos ni horarios. Preparar versión vertical 4:5 para publicación y versión 9:16 para stories. No generar texto nuevo ni sustituir letras.')
prompt_box('Prompt maestro D - Aftermovie emocional', 'Mejora estos clips reales de la fiesta y el pueblo para un aftermovie emocional y energético. Mantén caras y momentos auténticos, aumenta claridad en baja luz, reduce ruido, conserva piel natural y luces cálidas. El resultado debe transmitir comunidad, verano, música y orgullo de pueblo. No inventes personas, no cambies expresiones, no hagas que parezca una macrodiscoteca genérica.')

h1('5. Prompts detallados por pieza de campaña')

cards = [
('01', 'Teaser eclipse + dron', 'Reel', '1 junio', 'Crear primer golpe de FOMO: Santamar se alinea con el sol.', ['D01 entrada al pueblo', 'D02 cenital', 'D04 campanario', 'foto/logo Santamar'], 'Sube D01, D02 y D04. Mejorar como teaser cinematográfico de evento real: Santamar visto desde el aire, luz dorada, atmósfera de expectativa, azul cielo natural, contraste elegante, sensación de que algo grande se acerca. Mantener pueblo 100% real. No añadir eclipse falso si no está en el material; sugerirlo solo con color, sombra y atmósfera. Vertical 9:16, espacio superior para texto.', ['0-2s: “EL 12 DE AGOSTO”', '2-5s: “SANTAMAR SE ALINEA”', '5-8s: “CON EL SOL”', 'Final: “Síguenos. Se desbloquea pronto.”']),
('02', 'Santamar despierta', 'Reel', '8 junio', 'Mostrar el pueblo como destino emocional, no solo como cartel.', ['D01 entrada', 'D05 campos/río', 'calle vacía', 'vecino caminando'], 'Elevar clips reales de pueblo al amanecer/atardecer con estética documental premium. Sensación de calma antes de algo grande. Colores cálidos, detalle en piedra, calles y vegetación. Mantener realismo; no convertirlo en postal falsa. Preparar cortes suaves para vídeo de 10 segundos.', ['“Hay sitios que en agosto cambian de frecuencia.”', '“Santamar 2026 empieza ahora.”']),
('03', 'FOMO blanco', 'Reel', '12 junio', 'Instalar el código visual: blanco + eclipse + fiesta.', ['vídeos fiesta 2025 con gente', 'detalles de ropa blanca', 'D03 plaza', 'luces/decoración'], 'Mejora clips de fiesta real con estética Santamar White Festival: blanco luminoso, destellos suaves, energía ibicenca, música house, noche de verano. Mantener piel natural y rostros reales. No añadir masas de gente falsas ni luces imposibles. Resultado dinámico, elegante y local.', ['“EL BLANCO SERÁ EL CÓDIGO”', '“EL ECLIPSE, LA SEÑAL”', '“12 AGOSTO”']),
('04', 'Dron: antes del gran día', 'Reel', '17 junio', 'Crear contraste entre calma actual y evento futuro.', ['D06 calles vacías', 'D03 plaza tranquila', 'D04 campanario'], 'Dar al vídeo una estética de espera: pueblo tranquilo antes de transformarse. Luz de tarde, sombras suaves, textura real de calles y tejados, atmósfera misteriosa pero cálida. Mantener composición limpia para texto grande.', ['“Ahora parece tranquilo.”', '“En unas semanas sonará distinto.”']),
('05', 'Reveal Paul Darey', 'Reel', '22 junio', 'Presentar artista con percepción premium.', ['foto/vídeo oficial Paul Darey', 'D03 plaza', 'D08 espacio de fiesta si existe', 'logo evento'], 'Integrar material real del artista con planos reales de Santamar. Estética club ibicenco elegante: azul noche, blanco, dorado, ritmo, foco en headliner. No alterar rostro del artista ni inventar escenario. Hacer que el pueblo parezca preparado para recibir sonido Ibiza.', ['“DE IBIZA A SANTAMAR”', '“PAUL DAREY”', '“LA NOCHE DEL ECLIPSE”']),
('06', 'Recuerdo Ibicenca anterior', 'Reel', '26 junio', 'Usar prueba social: los que estuvieron saben.', ['clips 2025 bailando', 'barra', 'grupo amigos', 'luces', 'foto final'], 'Mejora material real de ediciones anteriores: más claridad, color cálido, movimiento vivo, sensación de recuerdo potente. Mantener grano natural si suma autenticidad. No sustituir caras ni crear público artificial. Preparar montaje rápido con flashazos.', ['“LOS QUE ESTUVIERON SABEN”', '“ESTO NO SE EXPLICA”', '“SE VIVE”']),
('07', 'Reveal OKKA', 'Reel', '29 junio', 'Segundo artista, energía directa.', ['foto/vídeo OKKA', 'plano carretera/entrada', 'D03 plaza', 'clips gente'], 'Crear reveal enérgico y fresco para DJ invitado. Mezclar material del artista con pueblo real, ritmo más rápido, cortes al beat, estética noche blanca. Mantener realista y reconocible. No generar textos dentro de la imagen.', ['“DESDE ASTURIAS”', '“OKKA”', '“12 AGOSTO · SANTAMAR”']),
('08', 'Landing / santamar.org', 'Carrusel + Reel corto', '1 julio', 'Mandar tráfico y hacer creíble el proyecto.', ['captura móvil web', 'D02 cenital', 'programa provisional', 'cartel'], 'Mejorar capturas y fondos para una pieza limpia de lanzamiento web: look digital premium, alto contraste, textos legibles, móvil claro, fondo Santamar real. No modificar URL ni textos de la web. Versiones 4:5 y 9:16.', ['“LA CUENTA ATRÁS YA ESTÁ EN MARCHA”', '“SANTAMAR.ORG”', '“PROGRAMA Y SORPRESAS”']),
('09', 'Reveal Dutari', 'Reel', '6 julio', 'Tercer artista, cierre del universo ibicenco.', ['foto/vídeo Dutari', 'D05 atardecer', 'luces noche', 'plaza'], 'Crear pieza elegante de sonido ibicenco: atardecer, azul noche, dorado solar, transición hacia fiesta. Mantener rostro y material del artista real. No inventar cabinas ni escenarios. Vertical 9:16 con portada limpia.', ['“DUTARI”', '“IBIZA SOUND”', '“TRES NOMBRES. UNA NOCHE.”']),
('10', 'Dron + eclipse educativo', 'Reel', '10 julio', 'Aprovechar interés por eclipse sin ponerse técnico.', ['D02 cenital', 'cielo/atardecer', 'D04 campanario', 'gráfico simple de fecha'], 'Mejora el material de dron y cielo para explicar el eclipse con emoción. Tono cinematográfico, cielo real, sombras suaves, sensación de acontecimiento astronómico. No añadir un eclipse falso hiperrealista sobre el pueblo salvo que sea un recurso claramente gráfico. Mantener Santamar reconocible.', ['“ESPAÑA VIVIRÁ UN ECLIPSE TOTAL”', '“SANTAMAR LO CONVIERTE EN UNA NOCHE”', '“12 AGOSTO”']),
('11', 'Dress code blanco', 'Carrusel + Reel', '13 julio', 'Hacer participativo el código blanco.', ['fotos de looks blancos', 'detalles tela', 'camiseta', 'grupo de amigos'], 'Mejorar fotos de ropa blanca y detalles para campaña elegante, luminosa y veraniega. Fondo real de Santamar, piel natural, blancos sin quemar, textura limpia. No cambiar prendas ni cuerpos. Preparar carrusel 4:5 y story 9:16.', ['“CÓDIGO BLANCO”', '“VEN COMO QUIERAS”', '“PERO VEN CON LUZ”']),
('12', 'Camiseta / merch limitado', 'Reel', '15 julio', 'Crear escasez real y deseo de pertenencia.', ['foto camiseta plana', 'camiseta puesta', 'detalle logo', 'plaza/fondo'], 'Convertir fotos reales de la camiseta Santamar 2026 en contenido de producto premium: iluminación limpia, textura textil visible, fondo del pueblo desenfocado si existe, sensación de edición limitada. No alterar logo, colores, texto ni costuras. Mantener aspecto realista.', ['“EDICIÓN LIMITADA”', '“NO ES UNA CAMISETA”', '“ES DECIR: YO ESTUVE ALLÍ”']),
('13', 'El pueblo se prepara', 'Reel', '20 julio', 'Humanizar organización y socios.', ['manos montando', 'voluntarios', 'carteles', 'sillas/mesas', 'D07 montaje'], 'Mejora clips reales de preparación con estilo documental emotivo: manos, trabajo, sonrisas, detalles, comunidad. Colores cálidos, grano suave, sensación auténtica. No hacer que parezca anuncio corporativo. Mantener imperfecciones humanas que transmitan verdad.', ['“NO SE MONTA EN UN DÍA”', '“SE MONTA CON MANOS”', '“Y CON GANAS”']),
('14', 'Aftermovie micro 2025', 'Reel', '24 julio', 'Prueba social fuerte para pauta.', ['los mejores 8-12 clips 2025', 'gente bailando', 'DJ', 'aplausos', 'noche'], 'Crear micro-aftermovie muy energético con material real de 2025. Mejorar baja luz, nitidez y color sin perder autenticidad. Cortes rápidos, beat claro, emoción y gente real. No inventar público ni confeti. El vídeo debe dar ganas de decir: este año voy.', ['“SI 2025 FUE ASÍ…”', '“IMAGINA 2026”', '“CON ECLIPSE”']),
('15', 'Programa 7-15 agosto', 'Publicación + Reel', '27 julio', 'Convertir información en contenido guardable.', ['programa cerrado', 'cartel', 'D02 pueblo', 'fotos actividades'], 'Crear visual informativo premium para programa: máxima legibilidad, jerarquía clara por días, fondo limpio inspirado en eclipse y blanco/dorado. No modificar fechas ni horarios. Exportar 4:5 para publicación, 9:16 para stories, y versión sin animación para WhatsApp.', ['“GUARDA EL PROGRAMA”', '“7-15 AGOSTO”', '“SANTAMAR 2026”']),
('16', 'Cuenta atrás 14 días', 'Reel', '29 julio', 'Urgencia y grupo de amigos.', ['D01 entrada', 'D03 plaza', 'flashes DJs', 'grupo amigos'], 'Crear vídeo de cuenta atrás con tensión positiva: cortes rápidos, textos grandes, cuenta regresiva, energía de última llamada. Mantener imágenes reales y no sobrecargar. Estética azul noche/dorado/blanco.', ['“14 DÍAS”', '“SI NO TIENES PLAN”', '“SANTAMAR LO RESUELVE”']),
('17', 'Última semana', 'Reel', '3 agosto', 'Abrir empuje final de asistencia.', ['D07 montaje', 'carteles colocados', 'gente preparando', 'D03 plaza'], 'Mejora material de montaje y pueblo para anuncio de última semana: energía creciente, ritmo, detalles reales, sensación de que ya está ocurriendo. No añadir elementos inexistentes. Portada con texto grande “ÚLTIMA SEMANA”.', ['“ESTA SEMANA SANTAMAR CAMBIA”', '“DEL 7 AL 15 DE AGOSTO”']),
('18', 'Guía práctica', 'Carrusel + Stories', '5 agosto', 'Resolver dudas y generar guardados.', ['mapa simple', 'ubicación', 'horarios', 'dress code', 'cartel'], 'Crear visuales limpios y legibles para guía práctica: cómo llegar, horario, dress code, recomendaciones. Estilo claro, premium y funcional. No decorar en exceso. Priorizar lectura en móvil.', ['“GUÍA RÁPIDA”', '“HORA · LUGAR · BLANCO”', '“GUÁRDALO”']),
('19', 'Mañana eclipse', 'Reel', '11 agosto', 'Último golpe emocional previo.', ['D09 atardecer', 'D03 plaza lista', 'DJs', 'detalle blanco'], 'Crear teaser final con máxima emoción: atardecer real, pueblo preparado, blanco, música, eclipse como símbolo. Ritmo ascendente, texto mínimo, sensación de “no lo vas a vivir dos veces”. No usar imágenes falsas del eclipse total sobre personas.', ['“MAÑANA”', '“BLANCO”', '“ECLIPSE”', '“SANTAMAR”']),
('20', 'Directo día grande', 'Stories/Reel', '12 agosto', 'Cobertura viva y repostable.', ['montaje mañana', 'llegada gente', 'dress code', 'DJs', 'ambiente', 'cierre'], 'Mejora clips rápidos del día para stories: claridad, color natural, texto legible, energía real. Mantener formato vertical. No procesar demasiado: debe sentirse en directo.', ['“HOY”', '“DESDE LAS 19:00”', '“ETIQUETA @ASOCIACIONSANTAMAR”']),
('21', 'Teaser aftermovie', 'Reel', '13 agosto', 'No dejar morir el pico de atención.', ['10 mejores clips noche', 'gente cantando/bailando', 'plano final'], 'Crear teaser de aftermovie emocional de 10 segundos. Mejora luz y detalle, conserva emoción real, cortes al beat, final con promesa “aftermovie pronto”. No inventar momentos.', ['“ANOCHE SANTAMAR HIZO HISTORIA”', '“ESTO ES SOLO EL TEASER”']),
('22', 'Aftermovie corto', 'Reel', '15 agosto', 'Cierre épico y captación tardía de seguidores.', ['D08 gente blanca', 'D09 atardecer', 'D10 luces', 'DJs', 'abrazos', 'cierre'], 'Crear aftermovie final de Santamar 2026: mezcla de pueblo, eclipse, música, blanco, comunidad y emoción. Estética cinematográfica, cálida y real. Mejorar baja luz, estabilizar, reducir ruido, mantener piel y caras naturales. No convertirlo en festival genérico: debe sentirse Santamar.', ['“30 AÑOS”', '“UNA NOCHE”', '“UN ECLIPSE”', '“SANTAMAR 2026”'])
]

for cid, title, typ, date, objective, assets, prompt, texts in cards:
    h2(f'{cid}. {title} ({typ}) - {date}')
    p(f'Objetivo: {objective}')
    h3('Material que hay que aportar')
    for a in assets: bullet(a)
    prompt_box('Prompt para pegar en Magnific / herramienta de mejora', prompt)
    h3('Texto en pantalla sugerido')
    for tx in texts: bullet(tx)
    h3('Montaje recomendado')
    for item in ['Hook visual en el primer segundo.', 'Cortes cada 1-2 segundos si es pieza de FOMO; cortes más largos si es emocional.', 'Terminar con CTA claro: seguir, guardar, compartir o etiquetar.', 'Portada con 2-4 palabras grandes y fondo limpio.']:
        bullet(item)
    h3('Negative prompt / evitar')
    p('No inventar edificios, no cambiar rostros, no crear multitudes falsas, no añadir texto ilegible generado por IA, no saturar colores, no usar estética de macrofestival genérico si se pierde la identidad del pueblo.', 'PromptBox')

h1('6. Prompts para imágenes fijas y carruseles')
image_prompts = [
('Cartel premium', 'Usar cartel real y fondo real de Santamar. Mejorar nitidez, contraste y jerarquía visual. Mantener todos los textos, fechas, logos y nombres exactamente iguales. Crear versión 4:5 para feed y 9:16 para stories. Estética blanco, dorado solar y azul noche.'),
('Portada de Reel', 'Crear portada vertical 9:16 con foto real del pueblo o evento, alto contraste, espacio central limpio y titular grande. Titular máximo 4 palabras. Mantener identidad Santamar 2026, sin elementos falsos.'),
('Carrusel programa', 'Diseñar carrusel informativo muy legible: una portada emocional, una slide por bloque de días, una slide especial para 12 agosto y una final con CTA. Priorizar lectura móvil. No usar párrafos largos.'),
('Patrocinadores', 'Crear imagen limpia de agradecimiento a patrocinadores con logos proporcionados. Fondo claro, orden visual, sin deformar logos. Incluir “Gracias por hacer posible Santamar 2026”.'),
('Stories cuenta atrás', 'Crear plantilla 9:16 con fondo real del pueblo, zona superior para “Quedan X días”, zona inferior para sticker de cuenta atrás. Estética eclipse y blanco premium.')
]
for title, text in image_prompts:
    h2(title)
    prompt_box('Prompt imagen', text)

h1('7. Checklist de rodaje por día')
check = [
('Antes de junio', 'Grabar D01-D06, fotos del pueblo, carteles, camiseta, capturas web, seleccionar clips 2025.'),
('20-30 junio', 'Pedir material oficial a DJs y permiso de publicación colaborativa.'),
('1-20 julio', 'Grabar looks blancos, merch, voluntarios, patrocinadores y preparación inicial.'),
('24-31 julio', 'Grabar cartel colocado en bares/comercios, programa cerrado, gente reaccionando o enseñando el cartel.'),
('7-11 agosto', 'Grabar montaje real todos los días: manos, caras, detalles, horarios, pueblo llenándose.'),
('12 agosto', 'Grabar en vertical todo: llegada, blanco, ambiente, DJs, público, detalles, cierre. Hacer backups esa noche.'),
('13-15 agosto', 'Seleccionar mejores clips, pedir vídeos a asistentes, crear teaser y aftermovie corto.')
]
t = doc.add_table(rows=1, cols=2)
for i,h in enumerate(['Momento','Qué grabar o preparar']): set_cell_text(t.cell(0,i), h, True, 'FFFFFF'); shade_cell(t.cell(0,i),'12355B')
for a,b in check:
    row=t.add_row().cells
    set_cell_text(row[0], a, True, '12355B')
    set_cell_text(row[1], b)
set_table_widths(t,[1.45,5.55])

h1('8. Nombres de archivo recomendados')
for item in [
    'D01_entrada_pueblo_goldenhour_01.mp4',
    'D03_plaza_atardecer_orbital_01.mp4',
    'IBICENCA2025_publico_baile_01.mp4',
    'DJ_pauldarey_material_oficial_01.mp4',
    'MERCH_camiseta_detalle_logo_01.jpg',
    'STORIES_cartel_bar_leon_01.jpg',
    'EVENTO12_llegada_gente_blanco_01.mp4',
    'EVENTO12_dj_publico_luces_01.mp4'
]: bullet(item)

h1('9. Control de calidad antes de publicar')
for item in [
    'Se entiende el mensaje sin sonido en 3 segundos.',
    'El texto no tapa caras ni elementos importantes del pueblo.',
    'La portada se lee en pequeño desde el grid de Instagram.',
    'El vídeo no parece generado desde cero: se reconoce Santamar.',
    'No hay fechas, nombres de DJs ni horarios alterados por IA.',
    'Tiene CTA: seguir, guardar, compartir, etiquetar o visitar santamar.org.',
    'La primera versión se prueba orgánicamente; solo se pauta si arranca bien.'
]: bullet(item)

# footer
for section in doc.sections:
    footer = section.footer.paragraphs[0]
    footer.text = 'Santamar 2026 - Guía de prompts y rodaje'
    footer.alignment = WD_ALIGN_PARAGRAPH.CENTER
    footer.runs[0].font.size = Pt(8)
    footer.runs[0].font.color.rgb = RGBColor(100,100,100)

doc.save(OUT)
print(OUT)
