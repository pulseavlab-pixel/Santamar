# PRD - Santamar 30 Aniversario

## 1. Resumen

La web de **Santamar 30 Aniversario** será una página móvil, visual, juvenil y orientada a generar FOMO para la Semana Cultural 2026 de la Asociación Cultural Virgen del Río, en Santa María del Río, León.

El foco principal será el evento del **12 de agosto**, desde las **19:00 h**, en el centro del pueblo:

**La Noche del Eclipse - V Fiesta Ibicenca**  
**Santamar White Festival**

El concepto mezcla eclipse solar, noche ibicenca, estética premium, energía joven y raíz rural leonesa.

## 2. Objetivos

- Generar expectativa y viralidad antes del evento.
- Dar protagonismo al 12 de agosto como gran highlight.
- Presentar el line-up: **Paul Darey**, **OKKA** y **Dutari**.
- Captar socios.
- Captar colaboradores y patrocinadores.
- Llevar tráfico a Instagram, TikTok y WhatsApp.
- Mostrar la programación de la Semana Cultural del 7 al 15 de agosto.
- Reforzar la imagen de Santamar como asociación viva, joven y ambiciosa.

## 3. Publico Objetivo

La web debe dirigirse a:

- Jóvenes desde 16 años.
- Vecinos de Santamar.
- Gente de León.
- Veraneantes.
- Peñas.
- Familias.
- Público interesado en música house, tech house, deep house y ambiente ibicenco.

La comunicación debe funcionar tanto para quienes ya conocen Santamar como para quienes descubren la asociación por primera vez.

## 4. Naming

### Marca principal

**Santamar 30 Aniversario**

### Evento destacado

**La Noche del Eclipse - V Fiesta Ibicenca**

### Submarca del evento

**Santamar White Festival**

### Claim principal

**El 12 de agosto, Santamar se alinea con el sol.**

### Claim secundario

**30 años. Una noche. Un eclipse.**

### Frase emocional

**Esto va a ser enorme.**

## 5. Tono De Comunicacion

El tono será:

- Atrevido.
- Gamberro.
- Juvenil.
- Cercano.
- Emocional.
- Premium.
- Poco institucional.

### Palabras a evitar

- Rave.
- Macrofiesta.
- Ritual.
- Culto.

También conviene evitar que parezca un evento descontrolado. La comunicación debe transmitir energía, pero también buen ambiente, organización y cuidado por el pueblo.

## 6. Direccion Visual

La estética debe mezclar:

- Eclipse solar.
- Noche oscura.
- Halo dorado.
- Blanco ibicenco.
- Medusas luminosas.
- Destellos coral, azul eléctrico, lima y magenta.
- Texturas rústicas de piedra, adobe y madera.
- Referencias al pueblo leonés.
- Aire de club Ibiza, pero aterrizado en Santamar.

Sensación buscada:

**Ibiza aterriza en un pueblo de León durante una noche irrepetible.**

La web debe ser especialmente potente en móvil.

## 7. Estructura Web

## 7.1 Hero Cinematografico

Primera pantalla de impacto.

Debe incluir:

- Logo Santamar.
- Eclipse animado.
- Contador hasta el 12 de agosto.
- Frase principal.
- CTAs visibles.
- Partículas solares.
- Medusas sutiles o luminosas.
- Sonido opcional, nunca activado por defecto.

Texto recomendado:

```text
SANTAMAR 30 ANIVERSARIO

El 12 de agosto,
Santamar se alinea con el sol.

La Noche del Eclipse
V Fiesta Ibicenca - Santamar White Festival

Desde las 19:00 h - Centro de Santa María del Río
Dress code blanco - Entrada gratuita - Aforo limitado

Esto va a ser enorme.
```

CTAs principales:

- **Hazte socio**
- **Quiero enterarme antes**
- **Síguenos en Instagram**

## 7.2 Santamar 30 Aniversario

Sección emocional de asociación.

Mensaje recomendado:

```text
30 años haciendo que agosto tenga otro nombre.
Santamar no es solo una semana cultural. Es volver, juntarse, preparar, bailar, ayudar y hacer que el pueblo siga latiendo.
```

El aniversario debe integrarse dentro del universo visual del eclipse, no como un bloque institucional separado.

## 7.3 La Noche Del Eclipse

Contenido:

- Fecha: **12 de agosto**.
- Hora: **desde las 19:00 h**.
- Lugar: centro de Santa María del Río.
- Entrada gratuita.
- Aforo limitado.
- Dress code blanco.
- Barra.
- Food trucks.
- Decoración.
- Luces.
- Visuales.
- Photocall.
- Merchandising.
- Medusas.
- Ambiente ibicenco.

Copy recomendado:

```text
El blanco será el código. El eclipse, la señal.
El 12 de agosto Santamar cambia de frecuencia.
```

## 7.4 Line-Up

DJs:

1. **Paul Darey**
2. **OKKA**
3. **Dutari**

Cada ficha debe tener:

- Foto.
- Nombre artístico.
- Mini biografía.
- Estilo musical.
- Instagram.
- Tratamiento visual premium.

Estilo musical general:

- House.
- Tech house.
- Deep house.
- Techno house.
- Covers.

Copy general:

```text
Un cartel para mirar dos veces.
Ibiza, Asturias y Santamar bajo el mismo eclipse.
```

Enlaces:

- Paul Darey: https://instagram.com/pauldarey
- OKKA: https://instagram.com/okkadj
- Dutari: https://instagram.com/agustin_dutari

## 7.5 Semana Cultural

Fechas:

**7 al 15 de agosto**

Funcionalidades:

- Calendario editable.
- Días no revelados con texto **Próximamente**.
- Día actual destacado automáticamente como **Hoy en Santamar**.
- Posibilidad de añadir evento a Google Calendar / Apple Calendar.
- Programación actualizable sin tocar mucho código.

Inspiración desde el programa 2025:

- Hacendera.
- Montaje de espacios.
- Actividades infantiles.
- Talleres.
- Exposición.
- Música.
- Bingo.
- Fiesta temática.
- Teatro.
- Cine de verano.
- Día del socio.
- Cena de socios.
- Reconocimiento a colaboradores.

## 7.6 Hazte Socio

Objetivo:

Captar nuevos socios y reforzar pertenencia.

Copy principal:

```text
Ser socio no es pagar una cuota.
Es hacer que esto siga pasando.
```

Cuotas:

- Menores de 14 años: **15 euros**.
- Mayores: **20 euros**.

Ventajas:

- Chocolate.
- Hamburguesa.
- Regalos.
- Información anticipada.
- Apoyo directo a la asociación.
- Participación en la Semana Cultural.

Pago:

**En persona.**

## 7.7 Formulario De Socio

Campos:

- Nombre.
- Apellidos.
- Edad.
- Teléfono.
- Email.
- Pueblo.
- Consentimiento RGPD.
- Si es menor: datos de padre, madre o tutor.

Funcionamiento:

El formulario debe generar un mensaje preparado por WhatsApp al número:

**+34 654 509 987**

## 7.8 Colaboradores

Tipos:

- Empresas.
- Vecinos.
- Patrocinadores.
- Instituciones.

Categorías:

- **Eclipse**
- **Sol**
- **Luna**
- **Estrella**

Formato recomendado:

Tarjetas homogéneas con:

- Nombre.
- Categoría.
- Enlace, si existe.

Los logos solo deberían usarse si tienen calidad suficiente. Si no, es preferible usar tarjetas elegantes con nombre para evitar una sección visualmente caótica.

## 7.9 Colabora / Empresas

Página o sección orientada a captar colaboradores.

Mensaje:

```text
Tu marca también puede formar parte de lo que pasa en Santamar.
```

Beneficios para colaboradores:

- Presencia en web.
- Folletos.
- Carteles.
- Redes sociales.
- Mención en evento.
- Presencia en barra.
- Photocall.

CTA:

**Quiero colaborar**

Destino:

WhatsApp o Instagram.

## 7.10 Normas Y Buen Ambiente

Tono directo.

Texto principal:

```text
Buen rollo sí. Botellón no.
```

Mensajes:

- Respeto al pueblo.
- Respeto a vecinos.
- Respeto a la organización.
- Evento gratuito, cuidado y con aforo limitado.
- No se permitirá botellón.
- Quien venga a molestar o alterar el ambiente quedará fuera y se actuará en consecuencia.

## 7.11 Contacto

Canales:

- Instagram: https://instagram.com/asociacionsantamar
- WhatsApp: **+34 654 509 987**
- Email: **asociacion@santamar.org**

## 8. Funcionalidades

### Imprescindibles

- Diseño responsive móvil-first.
- Contador al 12 de agosto.
- Calendario editable.
- Día actual destacado.
- Botón WhatsApp con mensaje predefinido.
- Formulario de socio que abre WhatsApp.
- Botones a Instagram, TikTok y Facebook.
- Sección de colaboradores.
- CTA **Quiero enterarme antes**.
- Sonido opcional activado por el usuario.
- Cumplimiento RGPD básico.
- Botón añadir a calendario.
- Idioma principal español.
- Opción futura de inglés.

### Deseables

- Animación de eclipse con scroll.
- Partículas solares.
- Medusas animadas.
- Parallax.
- Transiciones suaves.
- Integración feed Instagram.
- Analítica con Google Analytics o alternativa gratuita.

## 9. Requisitos Tecnicos

El dominio se gestionará desde IONOS / 1&1, pero la web estará alojada en un hosting gratuito.

Opciones recomendadas:

- **GitHub Pages**: ideal si la web es estática, gratuita y rápida.
- **Netlify**: buena para despliegue fácil, dominio personalizado y posibles formularios.
- **Vercel**: buena si se usa React o Next, aunque puede ser más técnico.
- **Cloudflare Pages**: rápida, gratuita y robusta.

Recomendación principal:

**Netlify o Cloudflare Pages**.

Motivo:

Permiten alojar gratis una web moderna, enlazar el dominio de IONOS mediante DNS y tener buen rendimiento sin servidor propio.

Arquitectura recomendada:

- Web estática.
- HTML/CSS/JS o Astro.
- Sin base de datos inicial.
- Datos editables en archivos JSON.
- Formularios mediante WhatsApp prellenado.
- Sin backend para reducir mantenimiento.

Contenido editable:

- `programacion.json`
- `djs.json`
- `colaboradores.json`
- `config.json`

Esto permitiría actualizar programación, artistas, colaboradores y fechas sin rehacer la web completa.

## 10. RGPD

La web debe incluir:

- Aviso legal.
- Política de privacidad.
- Checkbox de consentimiento en formularios.
- Texto claro indicando que los datos se usarán para gestionar la solicitud de socio o contacto.
- No activar cookies de analítica sin aviso si se usan Google Analytics u otras cookies.

Texto corto para formulario:

```text
Acepto que Santamar use estos datos para gestionar mi solicitud y contactar conmigo por WhatsApp o email.
```

## 11. Redes Sociales

### Enlaces

- Santamar: https://instagram.com/asociacionsantamar
- Paul Darey: https://instagram.com/pauldarey
- OKKA: https://instagram.com/okkadj
- Dutari: https://instagram.com/agustin_dutari

### Hashtags

```text
#Santamar30
#LaNocheDelEclipse
#SantamarWhiteFestival
#IbizaEnLeon
#Santamar2026
```

### Plan De Contenidos

- Junio: misterio, eclipse, 30 aniversario.
- 1 julio: lanzamiento web / coming soon.
- Julio semana 1: concepto y claim.
- Julio semana 2: dress code blanco y medusas.
- Julio semana 3: revelar DJs.
- Julio semana 4: colaboradores y detalles de evento.
- Agosto: cuenta atrás, programación diaria, montaje, stories, reels y llamadas a socios.
- 12 agosto: cobertura en directo.
- 13 agosto: teaser aftermovie.

## 12. Metricas De Exito

Medir:

- Clics a Instagram.
- Clics a WhatsApp.
- Formularios de socio iniciados.
- Nuevos socios.
- Nuevos colaboradores.
- Compartidos en redes.
- Visitas al calendario.
- Visitas al line-up.
- Tiempo medio en página.
- Asistencia al evento.

## 13. Calendario De Publicacion

### Antes del 1 de julio

- Preparar landing coming soon.
- Activar dominio.
- Publicar contador.
- Mostrar claim principal.
- Activar Instagram / WhatsApp.

### 1 de julio

Publicación de primera versión:

- Hero.
- Contador.
- CTA socios.
- Teaser evento 12 agosto.
- Redes.
- **Próximamente programación**.

### Julio

Añadir:

- Line-up.
- Colaboradores.
- Programación progresiva.
- Formulario socio.
- Normas.
- Kit colaboradores.

### Agosto

Activar:

- Día actual destacado.
- Cuenta atrás final.
- CTA fuerte a Instagram.
- Programación completa.
- Contenido en directo.

## 14. Material Necesario

### Ya aportado

- Logo Santamar.
- PDF Semana Cultural 2025.
- Cartel fiesta ibicenca 2026.
- Redes Santamar.
- Redes DJs.
- Email asociación.
- Teléfono WhatsApp.

### Pendiente

- Fotos profesionales DJs.
- Fotos del pueblo.
- Fotos de fiestas anteriores.
- Listado colaboradores.
- TikTok y Facebook exactos.
- Programación 2026 cuando esté definida.
- Texto legal / RGPD definitivo o datos legales de la asociación.

## 15. Riesgos

- Hosting gratuito puede tener limitaciones, pero para tráfico bajo es suficiente.
- Animaciones demasiado pesadas pueden perjudicar móvil.
- Feed de Instagram puede ser inestable o requerir herramientas externas.
- Formularios sin backend dependen de WhatsApp y acción manual del usuario.
- Si se mezclan logos de baja calidad, la sección colaboradores puede perder nivel visual.

## 16. Recomendacion Final

Crear una web estática espectacular, móvil-first, alojada en **Netlify o Cloudflare Pages**, con dominio conectado desde IONOS.

La primera versión debe salir el **1 de julio** como landing FOMO con contador y concepto fuerte. Después se desbloquean secciones: line-up, programación, socios, colaboradores y normas.

La dirección creativa queda clara:

```text
Santamar 30 Aniversario
La Noche del Eclipse
V Fiesta Ibicenca - Santamar White Festival

El 12 de agosto, Santamar se alinea con el sol.
Esto va a ser enorme.
```
