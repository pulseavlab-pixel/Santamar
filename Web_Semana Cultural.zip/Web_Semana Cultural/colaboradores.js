(function () {
  const form = document.querySelector("[data-collab-form]");
  const whatsappPhone = "34654509987";

  if (!form) return;

  form.addEventListener("submit", (event) => {
    event.preventDefault();
    const formData = new FormData(form);
    const message = [
      "Hola Santamar. Quiero colaborar como patrocinador/a.",
      "",
      `Nombre: ${formData.get("nombre")}`,
      `Empresa o marca: ${formData.get("empresa")}`,
      `Teléfono: ${formData.get("telefono")}`,
      `Modalidad: ${formData.get("modalidad")}`,
      "",
      `Mensaje: ${formData.get("mensaje") || "Sin mensaje adicional."}`,
      "",
      "Me interesa conocer la visibilidad en web, cartelería, flyers, redes y otros carteles según el grado de colaboración.",
    ].join("\n");

    window.open(`https://wa.me/${whatsappPhone}?text=${encodeURIComponent(message)}`, "_blank", "noopener,noreferrer");
  });
})();
