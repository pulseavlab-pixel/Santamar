﻿(function () {
  const data = window.SANTAMAR_DATA;
  const eventDate = new Date(data.eventDate);
  const $ = (selector, parent = document) => parent.querySelector(selector);
  const $$ = (selector, parent = document) => Array.from(parent.querySelectorAll(selector));

  function pad(value) {
    return String(Math.max(0, value)).padStart(2, "0");
  }

  function currentDate() {
    const simulatedDate = new URLSearchParams(window.location.search).get("simDate");
    return simulatedDate ? new Date(`${simulatedDate}T12:00:00`) : new Date();
  }

  function updateCountdown() {
    const total = Math.max(0, Math.floor((eventDate - currentDate()) / 1000));
    $("[data-party-days]").textContent = pad(Math.floor(total / 86400));
    $("[data-party-hours]").textContent = pad(Math.floor((total % 86400) / 3600));
    $("[data-party-minutes]").textContent = pad(Math.floor((total % 3600) / 60));
    $("[data-party-seconds]").textContent = pad(total % 60);
  }

  function countdownParts(targetDate) {
    const total = Math.max(0, Math.floor((new Date(targetDate) - currentDate()) / 1000));
    return {
      days: Math.floor(total / 86400),
      hours: Math.floor((total % 86400) / 3600),
      minutes: Math.floor((total % 3600) / 60),
    };
  }

  function whatsappUrl(message) {
    return `https://wa.me/${data.whatsappPhone}?text=${encodeURIComponent(message)}`;
  }

  function setupWhatsApp() {
    const messages = {
      info: "Hola Santamar. Quiero enterarme antes de las novedades de La Noche del Eclipse.",
      contact: "Hola Santamar. Quiero contactar por La Noche del Eclipse.",
    };

    $$("[data-party-whatsapp]").forEach((link) => {
      link.href = whatsappUrl(messages[link.dataset.partyWhatsapp] || messages.contact);
      link.target = "_blank";
      link.rel = "noreferrer";
    });
  }

  function renderDjs() {
    const container = $("[data-party-djs]");
    if (!container || !data || !Array.isArray(data.djs)) return;
    container.innerHTML = data.djs
      .slice()
      .sort((a, b) => new Date(a.revealDate || 0) - new Date(b.revealDate || 0))
      .map((dj, index) => {
        const isRevealed = !dj.revealDate || currentDate() >= new Date(dj.revealDate);
        const parts = countdownParts(dj.revealDate);
        if (!isRevealed) {
          return `
          <article class="party-dj-card locked ${index === 0 ? "featured" : ""}">
            <div class="dj-orbit-system" aria-hidden="true">
              <span class="dj-planet main"></span>
              <span class="dj-planet small one"></span>
              <span class="dj-planet small two"></span>
              <span class="dj-ring ring-a"></span>
              <span class="dj-ring ring-b"></span>
            </div>
            <div class="party-dj-number">0${index + 1}</div>
            <div class="party-dj-visual party-dj-locked" aria-hidden="true">
              <span>?</span>
            </div>
            <div class="party-dj-copy">
              <p>Revelación ${index + 1}</p>
              <h3>Nombre oculto</h3>
              <strong>${dj.revealLabel}</strong>
              <span>${dj.secretBio || "La página especial se abrirá por fases. Hasta entonces, solo llega la señal del eclipse."}</span>
              <div class="reveal-countdown">
                <div><b>${pad(parts.days)}</b><small>Días</small></div>
                <div><b>${pad(parts.hours)}</b><small>Horas</small></div>
                <div><b>${pad(parts.minutes)}</b><small>Min</small></div>
              </div>
            </div>
          </article>
        `;
        }
        const role = dj.name === "Paul Darey" ? "Internacional" : dj.name === "OKKA" ? "Asturias energy" : "Ibiza groove";
        const moment = dj.name === "Paul Darey" ? "Momento principal" : dj.name === "OKKA" ? "Subida de noche" : "Cierre elegante";
        const initials = dj.name
          .split(" ")
          .map((part) => part[0])
          .join("");
        return `
          <article class="party-dj-card ${index === 0 ? "featured" : ""}">
            <div class="dj-orbit-system" aria-hidden="true">
              <span class="dj-planet main"></span>
              <span class="dj-planet small one"></span>
              <span class="dj-planet small two"></span>
              <span class="dj-ring ring-a"></span>
              <span class="dj-ring ring-b"></span>
            </div>
            <div class="party-dj-number">0${index + 1}</div>
            <div class="party-dj-visual">
              ${dj.image ? `<img src="${dj.image}" alt="${dj.name}" loading="lazy">` : ""}
              <span>${initials}</span>
            </div>
            <div class="party-dj-copy">
              <p>${role}</p>
              <h3>${dj.name}</h3>
              <strong>${dj.style}</strong>
              <span>${dj.bio}</span>
              <div class="party-dj-meta">
                <em>${moment}</em>
                <a href="${dj.instagram}" target="_blank" rel="noreferrer">Instagram</a>
              </div>
            </div>
          </article>
        `;
      })
      .join("");
  }

  function setupReveal() {
    if (!("IntersectionObserver" in window)) {
      $$(".party-dj-card, .experience-grid article, .party-plan-inner").forEach((el) => el.classList.add("is-visible"));
      return;
    }
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) entry.target.classList.add("is-visible");
        });
      },
      { threshold: 0.16 }
    );

    $$(".party-dj-card, .experience-grid article, .party-plan-inner").forEach((el) => observer.observe(el));
  }

  updateCountdown();
  setInterval(updateCountdown, 1000);
  setupWhatsApp();
  renderDjs();
  setupReveal();
})();

