﻿(function () {
  const data = window.SANTAMAR_DATA;
  const eventDate = new Date(data.eventDate);
  const $ = (selector, parent = document) => parent.querySelector(selector);
  const $$ = (selector, parent = document) => Array.from(parent.querySelectorAll(selector));

  function pad(value) {
    return String(Math.max(0, value)).padStart(2, "0");
  }

  function currentDate() {
    const simulatedDate = new URLSearchParams(window.location.search).get("simDate");
    return simulatedDate ? new Date(`${simulatedDate}T12:00:00`) : new Date();
  }

  function updateCountdown() {
    const diff = eventDate - currentDate();
    const total = Math.max(0, Math.floor(diff / 1000));
    const days = Math.floor(total / 86400);
    const hours = Math.floor((total % 86400) / 3600);
    const minutes = Math.floor((total % 3600) / 60);
    const seconds = total % 60;

    $("[data-days]").textContent = pad(days);
    $("[data-hours]").textContent = pad(hours);
    $("[data-minutes]").textContent = pad(minutes);
    $("[data-seconds]").textContent = pad(seconds);
  }

  function countdownParts(targetDate) {
    const diff = new Date(targetDate) - currentDate();
    const total = Math.max(0, Math.floor(diff / 1000));
    return {
      days: Math.floor(total / 86400),
      hours: Math.floor((total % 86400) / 3600),
      minutes: Math.floor((total % 3600) / 60),
    };
  }

  function whatsappUrl(message) {
    return `https://wa.me/${data.whatsappPhone}?text=${encodeURIComponent(message)}`;
  }

  function setupWhatsAppLinks() {
    const messages = {
      info:
        "Hola Santamar. Quiero enterarme antes de las novedades de La Noche del Eclipse y la Semana Cultural.",
      sponsor:
        "Hola Santamar. Quiero información para colaborar con Santamar 30 Aniversario.",
      contact: "Hola Santamar. Quiero contactar con la asociación.",
    };

    $$("[data-whatsapp]").forEach((link) => {
      const key = link.dataset.whatsapp;
      link.href = whatsappUrl(messages[key] || messages.contact);
      link.target = "_blank";
      link.rel = "noreferrer";
    });
  }

  function renderDjs() {
    const container = $("[data-djs]");
    container.innerHTML = data.djs
      .slice()
      .sort((a, b) => new Date(a.revealDate || 0) - new Date(b.revealDate || 0))
      .map(
        (dj, index) => {
          const isRevealed = !dj.revealDate || currentDate() >= new Date(dj.revealDate);
          const parts = countdownParts(dj.revealDate);
          if (!isRevealed) {
            return `
        <article class="dj-card dj-card-locked reveal" style="--i:${index}">
          <div class="dj-portrait dj-portal" aria-hidden="true">
            <span>?</span>
          </div>
          <div class="dj-content">
            <p>Revelación ${index + 1} / ${dj.revealLabel}</p>
            <h3>Nombre oculto</h3>
            <strong>Pista del nombre oculto</strong>
            <span>${dj.secretBio || "Un planeta se acerca a Santamar. Cuando llegue la fecha, el cartel se abrirá."}</span>
            <div class="reveal-countdown" aria-label="Cuenta atrás para revelar DJ">
              <div><b>${pad(parts.days)}</b><small>Días</small></div>
              <div><b>${pad(parts.hours)}</b><small>Horas</small></div>
              <div><b>${pad(parts.minutes)}</b><small>Min</small></div>
            </div>
          </div>
        </article>
      `;
          }
          const initials = dj.name
            .split(" ")
            .map((part) => part[0])
            .join("");
          return `
        <article class="dj-card reveal" style="--i:${index}">
          <div class="dj-portrait">
            ${dj.image ? `<img src="${dj.image}" alt="${dj.name}" loading="lazy">` : ""}
            <span>${initials}</span>
          </div>
          <div class="dj-content">
            <p>${dj.tag} / ${dj.origin}</p>
            <h3>${dj.name}</h3>
            <strong>${dj.style}</strong>
            <span>${dj.bio}</span>
            <a href="${dj.instagram}" target="_blank" rel="noreferrer">Ver Instagram</a>
          </div>
        </article>
      `;
        }
      )
      .join("");
  }

  function renderProgram() {
    const params = new URLSearchParams(window.location.search);
    const simulatedDate = params.get("simDate");
    const today = simulatedDate ? new Date(`${simulatedDate}T12:00:00`) : new Date();
    const todayKey = today.toISOString().slice(0, 10);
    const container = $("[data-program]");

    container.innerHTML = data.program
      .map((event) => {
        const isToday = event.date === todayKey;
        const isHighlight = event.status === "highlight";
        return `
          <article class="timeline-item ${isToday ? "today" : ""} ${isHighlight ? "highlight" : ""} ${event.theme ? `theme-${event.theme}` : ""}">
            ${isHighlight ? '<div class="shooting-stars" aria-hidden="true"><span></span><span></span><span></span></div>' : ""}
            <div class="timeline-date">
              <span>${isToday ? "Hoy en Santamar" : event.day}</span>
              ${isToday ? '<strong>Lo que pasa hoy</strong>' : ""}
            </div>
            <div class="timeline-body">
              ${isHighlight ? '<div class="program-eclipse" aria-hidden="true"><span></span></div>' : ""}
              ${event.badge ? `<p class="program-badge">${event.badge}</p>` : ""}
              <h3>${event.title}</h3>
              ${isHighlight ? '<p class="fomo-line">El día que Santamar se alinea con el sol. Si solo vienes a una noche, que sea esta.</p>' : ""}
              <ul>
                ${event.items.map((item) => `<li>${item}</li>`).join("")}
              </ul>
            </div>
          </article>
        `;
      })
      .join("");
  }

  function renderSponsors() {
    const container = $("[data-sponsors]");
    container.innerHTML = data.sponsors
      .map(
        (sponsor) => {
          const slug = sponsor.name
            .normalize("NFD")
            .replace(/[\u0300-\u036f]/g, "")
            .toLowerCase()
            .replace(/[^a-z0-9]+/g, "-")
            .replace(/^-|-$/g, "");
          return `
        <article class="sponsor-card" data-sponsor="${slug}">
          ${sponsor.logo ? `<div class="sponsor-logo"><img src="${sponsor.logo}" alt="${sponsor.name}"></div>` : ""}
          <strong>${sponsor.name}</strong>
        </article>
      `;
        }
      )
      .join("");
  }

  function setupMemberForm() {
    const form = $("[data-member-form]");
    form.addEventListener("submit", (event) => {
      event.preventDefault();
      const formData = new FormData(form);
      const lines = [
        "Hola Santamar. Quiero hacerme socio/a.",
        "",
        `Nombre: ${formData.get("nombre")}`,
        `Apellidos: ${formData.get("apellidos")}`,
        `Edad: ${formData.get("edad")}`,
        `Teléfono: ${formData.get("telefono")}`,
        `Email: ${formData.get("email")}`,
        `Pueblo: ${formData.get("pueblo")}`,
      ];
      const tutor = formData.get("tutor");
      if (tutor) lines.push(`Padre/madre/tutor: ${tutor}`);
      lines.push("", "Acepto el tratamiento de datos para gestionar la solicitud.");
      window.open(whatsappUrl(lines.join("\n")), "_blank", "noopener,noreferrer");
    });
  }

  function setupCalendar() {
    const link = $("[data-calendar]");
    const start = "20260812T170000Z";
    const end = "20260812T230000Z";
    const text = encodeURIComponent("La Noche del Eclipse - Santamar White Festival");
    const details = encodeURIComponent(
      "V Fiesta Ibicenca. Line-up secreto con revelaciones en junio. Dress code blanco. Entrada gratuita y aforo limitado."
    );
    const location = encodeURIComponent("Santa María del Río, León");
    link.href = `https://calendar.google.com/calendar/render?action=TEMPLATE&text=${text}&dates=${start}/${end}&details=${details}&location=${location}`;
    link.target = "_blank";
    link.rel = "noreferrer";
  }

  function setupSound() {
    const button = $("[data-sound]");
    if (!button) return;
    let context;
    let oscillator;
    let gain;

    button.addEventListener("click", () => {
      const enabled = button.getAttribute("aria-pressed") === "true";
      if (enabled) {
        if (gain) gain.gain.exponentialRampToValueAtTime(0.0001, context.currentTime + 0.4);
        button.setAttribute("aria-pressed", "false");
        return;
      }

      context = context || new AudioContext();
      oscillator = context.createOscillator();
      gain = context.createGain();
      oscillator.type = "sine";
      oscillator.frequency.value = 92;
      gain.gain.value = 0.0001;
      oscillator.connect(gain);
      gain.connect(context.destination);
      oscillator.start();
      gain.gain.exponentialRampToValueAtTime(0.035, context.currentTime + 0.5);
      button.setAttribute("aria-pressed", "true");
    });
  }

  function setupMobileMenu() {
    const button = $("[data-menu-toggle]");
    const nav = $("[data-nav]");
    if (!button || !nav) return;

    function setOpen(open) {
      document.body.classList.toggle("menu-open", open);
      button.setAttribute("aria-expanded", String(open));
    }

    button.addEventListener("click", () => {
      setOpen(button.getAttribute("aria-expanded") !== "true");
    });

    nav.addEventListener("click", (event) => {
      if (event.target.closest("a")) setOpen(false);
    });

    window.addEventListener("keydown", (event) => {
      if (event.key === "Escape") setOpen(false);
    });

    window.addEventListener("resize", () => {
      if (window.innerWidth >= 720) setOpen(false);
    });
  }

  function setupReveal() {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) entry.target.classList.add("is-visible");
        });
      },
      { threshold: 0.18 }
    );

    $$(".section-inner, .feature-card, .dj-card, .timeline-item, .sponsor-card, .press-card").forEach((el) =>
      observer.observe(el)
    );
  }

  function animateSky() {
    const canvas = $("#sky");
    const ctx = canvas.getContext("2d");
    const particles = [];
    let width;
    let height;

    function resize() {
      width = canvas.width = window.innerWidth * devicePixelRatio;
      height = canvas.height = window.innerHeight * devicePixelRatio;
      canvas.style.width = `${window.innerWidth}px`;
      canvas.style.height = `${window.innerHeight}px`;
      particles.length = 0;
      const count = Math.min(110, Math.floor(window.innerWidth / 9));
      for (let i = 0; i < count; i += 1) {
        particles.push({
          x: Math.random() * width,
          y: Math.random() * height,
          r: (Math.random() * 1.8 + 0.5) * devicePixelRatio,
          vx: (Math.random() - 0.5) * 0.16 * devicePixelRatio,
          vy: (Math.random() - 0.5) * 0.12 * devicePixelRatio,
          hue: [42, 185, 320, 10, 76][Math.floor(Math.random() * 5)],
        });
      }
    }

    function frame() {
      ctx.clearRect(0, 0, width, height);
      particles.forEach((p) => {
        p.x += p.vx;
        p.y += p.vy;
        if (p.x < 0) p.x = width;
        if (p.x > width) p.x = 0;
        if (p.y < 0) p.y = height;
        if (p.y > height) p.y = 0;
        ctx.beginPath();
        ctx.fillStyle = `hsla(${p.hue}, 95%, 62%, .48)`;
        ctx.shadowColor = `hsla(${p.hue}, 95%, 62%, .8)`;
        ctx.shadowBlur = 14 * devicePixelRatio;
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fill();
      });
      requestAnimationFrame(frame);
    }

    resize();
    frame();
    window.addEventListener("resize", resize);
  }

  updateCountdown();
  setInterval(updateCountdown, 1000);
  setupWhatsAppLinks();
  renderDjs();
  renderProgram();
  renderSponsors();
  setupMemberForm();
  setupCalendar();
  setupSound();
  setupMobileMenu();
  setupReveal();
  animateSky();
})();

